
package modul4_kel15_tugas;

public class pendefinisi {
    public void identitas(){
        System.out.println("TUGAS MODUL 2");
        System.out.println("Kelompok 15 | Shift 1");
        System.out.println("Anadda Ferrell Ramadhan | 21120119130035");
        System.out.println("Kevin Ryo Pratama | 21120119130098");
        System.out.println("---------------------------------");
        System.out.println();
    }
}
